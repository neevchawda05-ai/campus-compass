'use client'

import { Compass, Moon, SlidersHorizontal, Sun } from 'lucide-react'

interface AppHeaderProps {
  theme: 'dark' | 'light'
  onToggleTheme: () => void
  onTogglePanel: () => void
  panelOpen: boolean
}

export function AppHeader({ theme, onToggleTheme, onTogglePanel, panelOpen }: AppHeaderProps) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b bg-card/60 px-3 backdrop-blur sm:px-5">
      <div className="flex items-center gap-2.5">
        <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-[0_0_20px_-4px_#1d4ed8]">
          <Compass className="size-4.5" aria-hidden="true" />
        </span>
        <h1 className="text-base font-semibold tracking-tight">
          Campus <span className="text-success">Compass</span>
        </h1>
      </div>

      <div
        className="ml-auto hidden items-center gap-2 rounded-full border bg-background/60 px-3 py-1 font-mono text-[11px] text-muted-foreground md:flex"
        aria-label="System status: 0 milliseconds server latency, offline graph ready"
      >
        <span className="relative flex size-2" aria-hidden="true">
          <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald opacity-60" />
          <span className="relative inline-flex size-2 rounded-full bg-emerald" />
        </span>
        <span>0ms Server Latency</span>
        <span className="text-border" aria-hidden="true">
          |
        </span>
        <span>Offline Graph Ready</span>
      </div>

      <div className="ml-auto flex items-center gap-1 md:ml-0">
        <button
          type="button"
          onClick={onTogglePanel}
          aria-expanded={panelOpen}
          aria-controls="route-panel"
          className="flex h-9 items-center gap-2 rounded-lg border px-3 text-sm font-medium hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none lg:hidden"
        >
          <SlidersHorizontal className="size-4" aria-hidden="true" />
          Plan
        </button>
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          className="flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
        >
          {theme === 'dark' ? <Sun className="size-4" /> : <Moon className="size-4" />}
        </button>
      </div>
    </header>
  )
}
