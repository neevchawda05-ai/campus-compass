'use client'

import { useMemo, useState } from 'react'
import { MousePointerClick } from 'lucide-react'
import { AppHeader } from './app-header'
import { CampusMap } from './campus-map'
import { RouteCard } from './route-card'
import { RoutePanel } from './route-panel'
import { EDGES, NODE_MAP, NODES, type Category } from '@/lib/campus-data'
import { buildRoute } from '@/lib/pathfinding'

interface RouteRequest {
  start: string
  end: string
}

export function CampusCompass() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')
  const [panelOpen, setPanelOpen] = useState(false)
  const [startId, setStartId] = useState('gate')
  const [destinationId, setDestinationId] = useState<string | null>(null)
  const [category, setCategory] = useState<'all' | Category>('all')
  const [accessible, setAccessible] = useState(false)
  const [elevatorOutage, setElevatorOutage] = useState(false)
  const [request, setRequest] = useState<RouteRequest | null>(null)
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null)

  const disabledNodeIds = useMemo(() => (elevatorOutage ? ['sci-elev'] : []), [elevatorOutage])

  const { route, routeError } = useMemo(() => {
    if (!request) return { route: null, routeError: null }
    if (request.start === request.end) {
      return { route: null, routeError: 'Start and destination are the same location.' }
    }
    const result = buildRoute(NODES, EDGES, NODE_MAP, request.start, request.end, {
      avoidStairs: accessible,
      disabledNodeIds,
    })
    if (!result) {
      const dest = NODE_MAP[request.end]
      return {
        route: null,
        routeError: accessible
          ? `No step-free route to ${dest.name} right now. ${elevatorOutage ? 'Elevator East Wing is out of service — campus staff have been notified.' : ''}`.trim()
          : `No route to ${dest.name} is currently available.`,
      }
    }
    return { route: result, routeError: null }
  }, [request, accessible, disabledNodeIds, elevatorOutage])

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    document.documentElement.classList.toggle('dark', next === 'dark')
  }

  const routeTo = (start: string, end: string) => {
    setStartId(start)
    setDestinationId(end)
    setRequest({ start, end })
  }

  const pickDestination = (id: string) => {
    if (id === startId) {
      setDestinationId(id)
      setRequest({ start: startId, end: id })
      return
    }
    routeTo(startId, id)
    setPanelOpen(false)
  }

  const reset = () => {
    setRequest(null)
    setDestinationId(null)
    setHoveredNodeId(null)
  }

  return (
    <div className="flex h-dvh flex-col bg-background font-sans text-foreground">
      <AppHeader
        theme={theme}
        onToggleTheme={toggleTheme}
        panelOpen={panelOpen}
        onTogglePanel={() => setPanelOpen((o) => !o)}
      />
      <div className="relative flex min-h-0 flex-1">
        <RoutePanel
          id="route-panel"
          open={panelOpen}
          onClose={() => setPanelOpen(false)}
          startId={startId}
          destinationId={destinationId}
          category={category}
          accessible={accessible}
          elevatorOutage={elevatorOutage}
          routeError={routeError}
          hasRoute={request !== null}
          onStartChange={setStartId}
          onDestinationChange={setDestinationId}
          onCategoryChange={setCategory}
          onAccessibleChange={setAccessible}
          onElevatorOutageChange={setElevatorOutage}
          onPickDestination={pickDestination}
          onSwap={() => {
            if (!destinationId) return
            const nextStart = destinationId
            const nextEnd = startId
            setStartId(nextStart)
            setDestinationId(nextEnd)
            if (request) setRequest({ start: nextStart, end: nextEnd })
          }}
          onFindRoute={() => {
            if (!destinationId) return
            setRequest({ start: startId, end: destinationId })
            setPanelOpen(false)
          }}
          onReset={reset}
          onScenario={(start, end) => {
            routeTo(start, end)
            setPanelOpen(false)
          }}
        />

        <main className="relative min-w-0 flex-1">
          <h2 className="sr-only">Campus map</h2>
          <CampusMap
            route={route}
            startId={startId}
            destinationId={destinationId}
            hoveredNodeId={hoveredNodeId}
            category={category}
            accessibleMode={accessible}
            disabledNodeIds={disabledNodeIds}
            onSelectNode={pickDestination}
            onHoverNode={setHoveredNodeId}
          >
            {route ? (
              <RouteCard
                route={route}
                hoveredNodeId={hoveredNodeId}
                onHoverStep={setHoveredNodeId}
                onClose={reset}
              />
            ) : (
              <div className="pointer-events-none absolute inset-x-3 bottom-3 mx-auto flex w-fit items-center gap-2 rounded-full border bg-card/90 px-4 py-2 text-sm text-muted-foreground shadow-lg backdrop-blur">
                <MousePointerClick className="size-4 text-success" aria-hidden="true" />
                {routeError ?? 'Tap any pin on the map to route there from your start location'}
              </div>
            )}
          </CampusMap>
        </main>
      </div>
    </div>
  )
}
