'use client'

import { useState } from 'react'
import {
  Accessibility,
  ArrowUp,
  ArrowUpDown,
  ChevronDown,
  Clock,
  CornerUpLeft,
  CornerUpRight,
  Flag,
  Footprints,
  Navigation,
  TrendingUp,
  TriangleAlert,
  X,
  type LucideIcon,
} from 'lucide-react'
import type { Route, StepIcon } from '@/lib/pathfinding'
import { NODE_MAP } from '@/lib/campus-data'
import { cn } from '@/lib/utils'

const STEP_ICONS: Record<StepIcon, LucideIcon> = {
  start: Navigation,
  left: CornerUpLeft,
  right: CornerUpRight,
  straight: ArrowUp,
  elevator: ArrowUpDown,
  stairs: TrendingUp,
  ramp: Accessibility,
  arrive: Flag,
}

interface RouteCardProps {
  route: Route
  hoveredNodeId: string | null
  onHoverStep: (nodeId: string | null) => void
  onClose: () => void
}

export function RouteCard({ route, hoveredNodeId, onHoverStep, onClose }: RouteCardProps) {
  const [expanded, setExpanded] = useState(true)
  const start = NODE_MAP[route.nodeIds[0]]
  const end = NODE_MAP[route.nodeIds[route.nodeIds.length - 1]]

  return (
    <section
      aria-label="Route summary"
      className="absolute inset-x-3 bottom-3 z-10 mx-auto max-w-2xl animate-in rounded-2xl border bg-card/95 shadow-2xl backdrop-blur-md duration-300 fade-in slide-in-from-bottom-4"
    >
      <div className="flex flex-wrap items-center gap-x-5 gap-y-3 p-4">
        <div className="flex min-w-0 flex-1 basis-56 flex-col gap-1">
          <p className="truncate text-xs text-muted-foreground">
            {start.name} <span aria-hidden="true">{'→'}</span>
            <span className="sr-only">to</span> {end.name}
          </p>
          <div className="flex items-baseline gap-4">
            <p className="flex items-baseline gap-1.5">
              <Footprints className="size-4 self-center text-muted-foreground" aria-hidden="true" />
              <span className="font-mono text-2xl font-semibold tabular-nums">{route.distance}</span>
              <span className="text-sm text-muted-foreground">meters</span>
            </p>
            <p className="flex items-baseline gap-1.5">
              <Clock className="size-4 self-center text-muted-foreground" aria-hidden="true" />
              <span className="font-mono text-2xl font-semibold tabular-nums">{route.minutes}</span>
              <span className="text-sm text-muted-foreground">{route.minutes === 1 ? 'min walk' : 'mins walk'}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {route.containsStairs ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-xs font-medium text-warning">
              <TriangleAlert className="size-3.5" aria-hidden="true" />
              Contains Stairs
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-success/40 bg-success/10 px-3 py-1 text-xs font-medium text-success">
              <Accessibility className="size-3.5" aria-hidden="true" />
              Step-Free Route Verified
            </span>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close route"
            className="flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <X className="size-4" />
          </button>
        </div>
      </div>

      <div className="border-t">
        <button
          type="button"
          onClick={() => setExpanded((e) => !e)}
          aria-expanded={expanded}
          aria-controls="route-steps"
          className="flex w-full items-center justify-between px-4 py-2.5 text-sm font-medium hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-inset"
        >
          <span>
            Turn-by-turn directions{' '}
            <span className="font-normal text-muted-foreground">({route.steps.length} steps)</span>
          </span>
          <ChevronDown className={cn('size-4 transition-transform', expanded && 'rotate-180')} aria-hidden="true" />
        </button>

        {expanded && (
          <ol id="route-steps" className="max-h-28 overflow-y-auto sm:max-h-52 px-2 pb-2">
            {route.steps.map((step, i) => {
              const Icon = STEP_ICONS[step.icon]
              const isStairs = step.icon === 'stairs'
              const isAccessible = step.icon === 'elevator' || step.icon === 'ramp'
              const active = hoveredNodeId === step.nodeId
              return (
                <li key={step.id}>
                  <div
                    tabIndex={0}
                    onPointerEnter={() => onHoverStep(step.nodeId)}
                    onPointerLeave={() => onHoverStep(null)}
                    onFocus={() => onHoverStep(step.nodeId)}
                    onBlur={() => onHoverStep(null)}
                    className={cn(
                      'flex items-start gap-3 rounded-lg px-2 py-2 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring',
                      active ? 'bg-primary/10' : 'hover:bg-muted/60',
                    )}
                  >
                    <span
                      className={cn(
                        'mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md border',
                        isStairs && 'border-warning/40 bg-warning/10 text-warning',
                        isAccessible && 'border-success/40 bg-success/10 text-success',
                        step.icon === 'arrive' && 'border-primary/40 bg-primary/15 text-primary dark:text-blue-300',
                        !isStairs && !isAccessible && step.icon !== 'arrive' && 'bg-muted text-muted-foreground',
                      )}
                    >
                      <Icon className="size-3.5" aria-hidden="true" />
                    </span>
                    <span className="flex min-w-0 flex-col">
                      <span className="text-sm leading-snug">
                        <span className="sr-only">Step {i + 1}: </span>
                        {step.text}
                      </span>
                      <span className="text-xs text-muted-foreground">{step.detail}</span>
                    </span>
                  </div>
                </li>
              )
            })}
          </ol>
        )}
      </div>
    </section>
  )
}
