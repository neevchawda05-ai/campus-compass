'use client'

import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react'
import { LocateFixed, Maximize, Minimize, ZoomIn, ZoomOut } from 'lucide-react'
import {
  BUILDINGS,
  EDGES,
  MAP_HEIGHT,
  MAP_WIDTH,
  NODE_MAP,
  NODES,
  TREES,
  type Category,
} from '@/lib/campus-data'
import type { Route } from '@/lib/pathfinding'
import { cn } from '@/lib/utils'

interface CampusMapProps {
  route: Route | null
  startId: string
  destinationId: string | null
  hoveredNodeId: string | null
  category: 'all' | Category
  accessibleMode: boolean
  disabledNodeIds: string[]
  onSelectNode: (id: string) => void
  onHoverNode: (id: string | null) => void
  children?: React.ReactNode
}

const MIN_SCALE = 0.7
const MAX_SCALE = 3

const CATEGORY_COLOR: Record<Category, string> = {
  classroom: '#3b82f6',
  lab: '#a78bfa',
  restroom: '#22d3ee',
  elevator: '#35d39a',
  food: '#f59e0b',
  landmark: '#94a3b8',
}

export function CampusMap({
  route,
  startId,
  destinationId,
  hoveredNodeId,
  category,
  accessibleMode,
  disabledNodeIds,
  onSelectNode,
  onHoverNode,
  children,
}: CampusMapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const svgRef = useRef<SVGSVGElement>(null)
  const dragRef = useRef<{ x: number; y: number; moved: boolean } | null>(null)
  const suppressClickRef = useRef(false)
  const [view, setView] = useState({ scale: 1, x: 0, y: 0 })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  useEffect(() => {
    const onChange = () => setIsFullscreen(document.fullscreenElement === containerRef.current)
    document.addEventListener('fullscreenchange', onChange)
    return () => document.removeEventListener('fullscreenchange', onChange)
  }, [])

  const zoomBy = useCallback((factor: number) => {
    setView((v) => {
      const scale = Math.min(MAX_SCALE, Math.max(MIN_SCALE, v.scale * factor))
      const cx = MAP_WIDTH / 2
      const cy = MAP_HEIGHT / 2
      return {
        scale,
        x: cx - ((cx - v.x) * scale) / v.scale,
        y: cy - ((cy - v.y) * scale) / v.scale,
      }
    })
  }, [])

  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return
    try {
      if (document.fullscreenElement) await document.exitFullscreen()
      else await containerRef.current.requestFullscreen()
    } catch {
      setIsFullscreen((f) => !f)
    }
  }, [])

  const svgUnitsPerPixel = () => {
    const rect = svgRef.current?.getBoundingClientRect()
    if (!rect) return 1
    return Math.max(MAP_WIDTH / rect.width, MAP_HEIGHT / rect.height)
  }

  const handlePointerDown = (e: ReactPointerEvent<SVGSVGElement>) => {
    if (e.button !== 0) return
    dragRef.current = { x: e.clientX, y: e.clientY, moved: false }
  }

  const handlePointerMove = (e: ReactPointerEvent<SVGSVGElement>) => {
    const drag = dragRef.current
    if (!drag) return
    const dx = e.clientX - drag.x
    const dy = e.clientY - drag.y
    if (!drag.moved && Math.hypot(dx, dy) < 4) return
    if (!drag.moved) {
      drag.moved = true
      setIsDragging(true)
      svgRef.current?.setPointerCapture(e.pointerId)
    }
    const k = svgUnitsPerPixel()
    setView((v) => ({ ...v, x: v.x + dx * k, y: v.y + dy * k }))
    drag.x = e.clientX
    drag.y = e.clientY
  }

  const endDrag = () => {
    suppressClickRef.current = dragRef.current?.moved ?? false
    dragRef.current = null
    setIsDragging(false)
  }

  const routeNodeIds = new Set(route?.nodeIds ?? [])
  const routeKey = route ? `${route.nodeIds.join('-')}-${route.accessibleMode}` : 'none'
  const routeColor = route?.accessibleMode ? 'var(--emerald)' : '#3b82f6'
  const disabled = new Set(disabledNodeIds)

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative h-full w-full overflow-hidden bg-[var(--map-ground)]',
        isFullscreen && 'fixed inset-0 z-50',
      )}
    >
      <svg
        ref={svgRef}
        viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
        preserveAspectRatio="xMidYMid meet"
        className={cn('h-full w-full touch-none select-none', isDragging ? 'cursor-grabbing' : 'cursor-grab')}
        role="application"
        aria-label="Interactive campus map. Select a location pin to set it as your destination."
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onPointerLeave={endDrag}
      >
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="var(--map-walk)" strokeWidth="0.6" opacity="0.5" />
          </pattern>
          <filter id="route-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <g transform={`translate(${view.x} ${view.y}) scale(${view.scale})`}>
          <rect x={-500} y={-500} width={MAP_WIDTH + 1000} height={MAP_HEIGHT + 1000} fill="url(#grid)" />

          <g aria-hidden="true">
            <rect x={30} y={390} width={60} height={290} rx={20} fill="var(--map-grass)" />
            <rect x={360} y={260} width={280} height={280} rx={140} fill="var(--map-grass)" opacity="0.6" />
            <rect x={920} y={340} width={60} height={340} rx={20} fill="var(--map-grass)" />
            <rect x={30} y={60} width={60} height={160} rx={20} fill="var(--map-grass)" />
            <rect x={620} y={30} width={360} height={70} rx={24} fill="var(--map-grass)" />
            <circle cx={500} cy={400} r={62} fill="var(--map-walk)" />
            <circle cx={500} cy={400} r={46} fill="none" stroke="var(--map-building-stroke)" strokeDasharray="3 6" />
          </g>

          <g aria-hidden="true">
            {EDGES.map((edge) => {
              const a = NODE_MAP[edge.from]
              const b = NODE_MAP[edge.to]
              const dimmed = (accessibleMode && edge.requiresStairs) || disabled.has(edge.from) || disabled.has(edge.to)
              return (
                <line
                  key={`walk-${edge.id}`}
                  x1={a.x}
                  y1={a.y}
                  x2={b.x}
                  y2={b.y}
                  stroke="var(--map-walk)"
                  strokeWidth={14}
                  strokeLinecap="round"
                  opacity={dimmed ? 0.35 : 1}
                />
              )
            })}
          </g>

          <g aria-hidden="true">
            {BUILDINGS.map((b) => (
              <g key={b.id}>
                <rect
                  x={b.x}
                  y={b.y}
                  width={b.width}
                  height={b.height}
                  rx={14}
                  fill="var(--map-building)"
                  stroke="var(--map-building-stroke)"
                  strokeWidth={1.5}
                  opacity={0.92}
                />
                <text
                  x={b.x + 12}
                  y={b.y + 22}
                  fill="var(--map-label)"
                  fontSize={12}
                  fontWeight={600}
                  letterSpacing="0.08em"
                  className="uppercase"
                >
                  {b.name}
                </text>
              </g>
            ))}
          </g>

          <g aria-hidden="true">
            {EDGES.map((edge) => {
              const a = NODE_MAP[edge.from]
              const b = NODE_MAP[edge.to]
              const isStairs = edge.kind === 'stairs'
              const isElevator = edge.kind === 'elevator'
              const dimmed = (accessibleMode && isStairs) || disabled.has(edge.from) || disabled.has(edge.to)
              return (
                <line
                  key={`edge-${edge.id}`}
                  x1={a.x}
                  y1={a.y}
                  x2={b.x}
                  y2={b.y}
                  stroke={isStairs ? 'var(--warning)' : isElevator ? 'var(--emerald)' : 'var(--map-building-stroke)'}
                  strokeWidth={isStairs || isElevator ? 2 : 1.5}
                  strokeDasharray={isStairs ? '6 5' : isElevator ? '2 4' : undefined}
                  strokeLinecap="round"
                  opacity={dimmed ? 0.2 : 0.85}
                />
              )
            })}
          </g>

          <g aria-hidden="true">
            {TREES.map(([x, y, r], i) => (
              <g key={i}>
                <circle cx={x} cy={y} r={r} fill="var(--map-tree)" opacity={0.85} />
                <circle cx={x - r * 0.3} cy={y - r * 0.3} r={r * 0.4} fill="var(--map-grass)" opacity={0.5} />
              </g>
            ))}
          </g>

          {route && (
            <g key={routeKey} aria-hidden="true">
              <polyline
                points={route.segments.map((s) => `${s.from.x},${s.from.y} ${s.to.x},${s.to.y}`).join(' ')}
                fill="none"
                stroke={routeColor}
                strokeWidth={10}
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity={0.35}
                filter="url(#route-glow)"
                pathLength={1}
                className="route-draw"
              />
              <polyline
                points={route.segments.map((s) => `${s.from.x},${s.from.y} ${s.to.x},${s.to.y}`).join(' ')}
                fill="none"
                stroke={routeColor}
                strokeWidth={5}
                strokeLinecap="round"
                strokeLinejoin="round"
                pathLength={1}
                className="route-draw"
              />
              <polyline
                points={route.segments.map((s) => `${s.from.x},${s.from.y} ${s.to.x},${s.to.y}`).join(' ')}
                fill="none"
                stroke="white"
                strokeWidth={2}
                strokeLinecap="round"
                opacity={0.8}
                className="route-flow"
              />
              {route.segments
                .filter((s) => s.edge.requiresStairs)
                .map((s) => (
                  <line
                    key={`stairs-${s.edge.id}`}
                    x1={s.from.x}
                    y1={s.from.y}
                    x2={s.to.x}
                    y2={s.to.y}
                    stroke="var(--warning)"
                    strokeWidth={6}
                    strokeDasharray="10 7"
                    strokeLinecap="round"
                  />
                ))}
            </g>
          )}

          <g>
            {NODES.map((node) => {
              const isStart = node.id === startId
              const isDestination = node.id === destinationId
              const isHovered = node.id === hoveredNodeId
              const onRoute = routeNodeIds.has(node.id)
              const isDisabled = disabled.has(node.id)
              const matchesCategory = category === 'all' || node.category === category
              const faded = !matchesCategory && !isStart && !isDestination && !onRoute
              const color = isStart ? 'var(--emerald)' : isDestination ? '#1d4ed8' : CATEGORY_COLOR[node.category]
              const radius = isStart || isDestination ? 11 : node.category === 'landmark' ? 6 : 8
              const showLabel = !faded && (node.category !== 'landmark' || isStart || isDestination || onRoute || isHovered)

              return (
                <g
                  key={node.id}
                  role="button"
                  tabIndex={0}
                  aria-label={`${node.name}, ${node.building}, floor ${node.floor}${isDisabled ? ', out of service' : ''}. Set as destination.`}
                  className="cursor-pointer outline-none [&:focus-visible>circle.focus-ring]:opacity-100"
                  opacity={faded ? 0.25 : 1}
                  onClick={() => {
                    if (!suppressClickRef.current) onSelectNode(node.id)
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault()
                      onSelectNode(node.id)
                    }
                  }}
                  onPointerEnter={() => onHoverNode(node.id)}
                  onPointerLeave={() => onHoverNode(null)}
                  onFocus={() => onHoverNode(node.id)}
                  onBlur={() => onHoverNode(null)}
                >
                  <circle cx={node.x} cy={node.y} r={22} fill="transparent" />
                  <circle
                    className="focus-ring opacity-0"
                    cx={node.x}
                    cy={node.y}
                    r={radius + 6}
                    fill="none"
                    stroke="var(--ring)"
                    strokeWidth={2}
                  />
                  {(isHovered || isDestination) && (
                    <circle className="node-pulse" cx={node.x} cy={node.y} r={radius + 2} fill={color} opacity={0.5} />
                  )}
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={isHovered ? radius + 3 : radius}
                    fill={isDisabled ? 'var(--destructive)' : color}
                    stroke="var(--map-ground)"
                    strokeWidth={3}
                    className="transition-all duration-200"
                  />
                  {(isStart || isDestination) && <circle cx={node.x} cy={node.y} r={4} fill="white" />}
                  {showLabel && (
                    <g>
                      <text
                        x={node.x}
                        y={node.labelBelow ? node.y + radius + 20 : node.y - radius - 9}
                        textAnchor="middle"
                        fontSize={isHovered ? 14 : 12.5}
                        fontWeight={600}
                        fill="currentColor"
                        stroke="var(--map-ground)"
                        strokeWidth={4}
                        paintOrder="stroke"
                        className="text-foreground transition-all"
                      >
                        {node.name}
                        {node.floor > 1 ? ` · F${node.floor}` : ''}
                        {isDisabled ? ' (closed)' : ''}
                      </text>
                    </g>
                  )}
                </g>
              )
            })}
          </g>
        </g>
      </svg>

      <div className="absolute top-3 right-3 flex flex-col gap-1 rounded-xl border bg-card/90 p-1 shadow-lg backdrop-blur">
        <MapControl label="Zoom in" onClick={() => zoomBy(1.25)}>
          <ZoomIn className="size-4" />
        </MapControl>
        <MapControl label="Zoom out" onClick={() => zoomBy(0.8)}>
          <ZoomOut className="size-4" />
        </MapControl>
        <MapControl label="Reset map view" onClick={() => setView({ scale: 1, x: 0, y: 0 })}>
          <LocateFixed className="size-4" />
        </MapControl>
        <MapControl label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'} onClick={toggleFullscreen}>
          {isFullscreen ? <Minimize className="size-4" /> : <Maximize className="size-4" />}
        </MapControl>
      </div>

      <MapLegend />

      {children}
    </div>
  )
}

function MapControl({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className="flex size-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
    >
      {children}
    </button>
  )
}

function MapLegend() {
  return (
    <div className="absolute top-3 left-3 hidden flex-col gap-1.5 rounded-xl border bg-card/90 px-3 py-2.5 text-xs text-muted-foreground shadow-lg backdrop-blur sm:flex">
      <span className="font-mono text-[10px] tracking-widest uppercase">Legend</span>
      <LegendItem>
        <svg width="28" height="6" aria-hidden="true">
          <line x1="2" y1="3" x2="26" y2="3" stroke="var(--emerald)" strokeWidth="4" strokeLinecap="round" />
        </svg>
        Step-free route
      </LegendItem>
      <LegendItem>
        <svg width="28" height="6" aria-hidden="true">
          <line x1="2" y1="3" x2="26" y2="3" stroke="#3b82f6" strokeWidth="4" strokeLinecap="round" />
        </svg>
        Fastest route
      </LegendItem>
      <LegendItem>
        <svg width="28" height="6" aria-hidden="true">
          <line x1="2" y1="3" x2="26" y2="3" stroke="var(--warning)" strokeWidth="3" strokeDasharray="5 4" />
        </svg>
        Staircase
      </LegendItem>
      <LegendItem>
        <svg width="28" height="6" aria-hidden="true">
          <line x1="2" y1="3" x2="26" y2="3" stroke="var(--emerald)" strokeWidth="3" strokeDasharray="2 3" />
        </svg>
        Elevator link
      </LegendItem>
    </div>
  )
}

function LegendItem({ children }: { children: React.ReactNode }) {
  return <span className="flex items-center gap-2">{children}</span>
}
