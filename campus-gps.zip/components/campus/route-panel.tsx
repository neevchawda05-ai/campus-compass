'use client'

import { useId, useState, type KeyboardEvent } from 'react'
import {
  Accessibility,
  ArrowDownUp,
  ArrowUpDown,
  Bath,
  CircleDot,
  FlaskConical,
  GraduationCap,
  Landmark,
  MapPin,
  Navigation,
  Play,
  RotateCcw,
  Search,
  TriangleAlert,
  Utensils,
  X,
  type LucideIcon,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { CATEGORY_FILTERS, NODES, type Category } from '@/lib/campus-data'
import { cn } from '@/lib/utils'

const CATEGORY_ICONS: Record<Category, LucideIcon> = {
  classroom: GraduationCap,
  lab: FlaskConical,
  restroom: Bath,
  elevator: ArrowUpDown,
  food: Utensils,
  landmark: Landmark,
}

const DEMO_SCENARIOS = [
  { label: 'Gate → Room 204', start: 'gate', end: 'room-204' },
  { label: 'Gate → Library', start: 'gate', end: 'library' },
  { label: 'Auditorium → Chem Lab', start: 'auditorium', end: 'sci-lab' },
]

interface RoutePanelProps {
  id: string
  open: boolean
  onClose: () => void
  startId: string
  destinationId: string | null
  category: 'all' | Category
  accessible: boolean
  elevatorOutage: boolean
  routeError: string | null
  hasRoute: boolean
  onStartChange: (id: string) => void
  onDestinationChange: (id: string | null) => void
  onCategoryChange: (c: 'all' | Category) => void
  onAccessibleChange: (v: boolean) => void
  onElevatorOutageChange: (v: boolean) => void
  onPickDestination: (id: string) => void
  onSwap: () => void
  onFindRoute: () => void
  onReset: () => void
  onScenario: (start: string, end: string) => void
}

export function RoutePanel(props: RoutePanelProps) {
  const {
    id,
    open,
    onClose,
    startId,
    destinationId,
    category,
    accessible,
    elevatorOutage,
    routeError,
    hasRoute,
    onStartChange,
    onDestinationChange,
    onCategoryChange,
    onAccessibleChange,
    onElevatorOutageChange,
    onPickDestination,
    onSwap,
    onFindRoute,
    onReset,
    onScenario,
  } = props

  const [query, setQuery] = useState('')
  const [activeIndex, setActiveIndex] = useState(0)
  const listId = useId()

  const normalized = query.trim().toLowerCase()
  const results = NODES.filter(
    (n) =>
      (category === 'all' || n.category === category) &&
      (normalized === '' ||
        n.name.toLowerCase().includes(normalized) ||
        n.building.toLowerCase().includes(normalized)),
  )

  const choose = (nodeId: string) => {
    onPickDestination(nodeId)
    setQuery('')
    setActiveIndex(0)
  }

  const handleSearchKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActiveIndex((i) => Math.min(results.length - 1, i + 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActiveIndex((i) => Math.max(0, i - 1))
    } else if (e.key === 'Enter') {
      if (e.nativeEvent.isComposing || e.keyCode === 229) return
      const target = results[activeIndex]
      if (target) {
        e.preventDefault()
        choose(target.id)
      }
    } else if (e.key === 'Escape') {
      setQuery('')
    }
  }

  return (
    <aside
      id={id}
      aria-label="Search and route planner"
      className={cn(
        'z-30 flex-col overflow-y-auto border-r bg-sidebar',
        'fixed inset-x-3 top-[4.25rem] bottom-3 rounded-2xl border shadow-2xl lg:static lg:inset-auto lg:w-[380px] lg:shrink-0 lg:rounded-none lg:border-y-0 lg:border-l-0 lg:shadow-none',
        open ? 'flex' : 'hidden lg:flex',
      )}
    >
      <div className="flex items-center justify-between px-5 pt-4 lg:hidden">
        <span className="text-sm font-semibold">Plan your route</span>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close panel"
          className="flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted"
        >
          <X className="size-4" />
        </button>
      </div>

      <section className="flex flex-col gap-3 p-5" aria-labelledby="search-heading">
        <h2 id="search-heading" className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
          Find a place
        </h2>
        <div className="relative">
          <Search
            className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <input
            type="search"
            role="combobox"
            aria-expanded={results.length > 0}
            aria-controls={listId}
            aria-autocomplete="list"
            aria-activedescendant={results[activeIndex] ? `${listId}-${results[activeIndex].id}` : undefined}
            aria-label="Search campus locations"
            placeholder="Search rooms, labs, food…"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setActiveIndex(0)
            }}
            onKeyDown={handleSearchKey}
            className="h-10 w-full rounded-xl border bg-background pr-3 pl-9 text-sm outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
          />
        </div>

        <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter by category">
          {CATEGORY_FILTERS.map((filter) => (
            <button
              key={filter.id}
              type="button"
              aria-pressed={category === filter.id}
              onClick={() => {
                onCategoryChange(filter.id)
                setActiveIndex(0)
              }}
              className={cn(
                'rounded-full border px-3 py-1 text-xs font-medium transition-colors focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none',
                category === filter.id
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'bg-background text-muted-foreground hover:text-foreground',
              )}
            >
              {filter.label}
            </button>
          ))}
        </div>

        <ul
          id={listId}
          role="listbox"
          aria-label="Matching locations"
          className="flex max-h-48 flex-col gap-0.5 overflow-y-auto rounded-xl border bg-background p-1"
        >
          {results.length === 0 && <li className="px-3 py-4 text-center text-sm text-muted-foreground">No matches</li>}
          {results.map((node, i) => {
            const Icon = CATEGORY_ICONS[node.category]
            const selected = node.id === destinationId
            return (
              <li
                key={node.id}
                id={`${listId}-${node.id}`}
                role="option"
                aria-selected={i === activeIndex}
                onClick={() => choose(node.id)}
                onPointerEnter={() => setActiveIndex(i)}
                className={cn(
                  'flex cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm',
                  i === activeIndex && 'bg-muted',
                )}
              >
                <Icon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <span className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate font-medium">{node.name}</span>
                  <span className="truncate text-xs text-muted-foreground">
                    {node.building} · {node.floor === 0 ? 'Ground' : `Floor ${node.floor}`}
                  </span>
                </span>
                {selected && <MapPin className="size-4 shrink-0 text-primary dark:text-blue-400" aria-label="Current destination" />}
              </li>
            )
          })}
        </ul>
      </section>

      <section className="flex flex-col gap-3 border-t p-5" aria-labelledby="planner-heading">
        <h2 id="planner-heading" className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
          Route planner
        </h2>

        <div className="relative flex flex-col gap-2">
          <LocationSelect
            label="Start location"
            icon={<CircleDot className="size-4 text-emerald" aria-hidden="true" />}
            value={startId}
            onChange={onStartChange}
          />
          <LocationSelect
            label="Destination"
            icon={<MapPin className="size-4 text-primary dark:text-blue-400" aria-hidden="true" />}
            value={destinationId ?? ''}
            placeholder="Choose a destination"
            onChange={(v) => onDestinationChange(v || null)}
          />
          <button
            type="button"
            onClick={onSwap}
            aria-label="Swap start and destination"
            className="absolute top-1/2 right-3 flex size-7 -translate-y-1/2 items-center justify-center rounded-full border bg-card text-muted-foreground shadow-sm hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <ArrowDownUp className="size-3.5" />
          </button>
        </div>

        <label
          className={cn(
            'flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-colors',
            accessible ? 'border-success/50 bg-success/10' : 'bg-background hover:bg-muted/50',
          )}
        >
          <span
            className={cn(
              'flex size-9 shrink-0 items-center justify-center rounded-lg',
              accessible ? 'bg-emerald text-slate-950' : 'bg-muted text-muted-foreground',
            )}
          >
            <Accessibility className="size-5" aria-hidden="true" />
          </span>
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="text-sm font-medium">Step-Free Accessible Route</span>
            <span className="text-xs text-muted-foreground">
              {accessible ? 'Ramps & elevators only' : 'Wheelchair friendly — avoids stairs'}
            </span>
          </span>
          <Switch checked={accessible} onChange={onAccessibleChange} label="Step-Free Accessible Route" />
        </label>

        {routeError && (
          <p
            role="alert"
            className="flex items-start gap-2 rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"
          >
            <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            {routeError}
          </p>
        )}

        <div className="flex gap-2">
          <Button size="lg" className="h-10 flex-1 hover:bg-primary/90" onClick={onFindRoute} disabled={!destinationId}>
            <Navigation data-icon="inline-start" />
            Find Route
          </Button>
          <Button size="lg" variant="outline" className="h-10" onClick={onReset} disabled={!hasRoute && !destinationId}>
            <RotateCcw data-icon="inline-start" />
            Reset Route
          </Button>
        </div>
      </section>

      <section className="flex flex-col gap-3 border-t p-5" aria-labelledby="demo-heading">
        <h2 id="demo-heading" className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
          Demo scenarios
        </h2>
        <div className="flex flex-col gap-1.5">
          {DEMO_SCENARIOS.map((s) => (
            <button
              key={s.label}
              type="button"
              onClick={() => onScenario(s.start, s.end)}
              className="flex items-center gap-2 rounded-lg border bg-background px-3 py-2 text-left text-sm hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
            >
              <Play className="size-3.5 text-success" aria-hidden="true" />
              {s.label}
            </button>
          ))}
        </div>
        <label className="flex cursor-pointer items-center gap-3 rounded-xl border bg-background p-3">
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="text-sm font-medium">Elevator East Wing outage</span>
            <span className="text-xs text-muted-foreground">Simulate a live maintenance alert</span>
          </span>
          <Switch
            checked={elevatorOutage}
            onChange={onElevatorOutageChange}
            label="Simulate Elevator East Wing outage"
            tone="destructive"
          />
        </label>
      </section>
    </aside>
  )
}

function LocationSelect({
  label,
  icon,
  value,
  placeholder,
  onChange,
}: {
  label: string
  icon: React.ReactNode
  value: string
  placeholder?: string
  onChange: (value: string) => void
}) {
  const selectId = useId()
  return (
    <div className="relative">
      <label htmlFor={selectId} className="sr-only">
        {label}
      </label>
      <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2">{icon}</span>
      <span className="pointer-events-none absolute top-1.5 left-9 text-[10px] font-medium tracking-wide text-muted-foreground uppercase">
        {label}
      </span>
      <select
        id={selectId}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-14 w-full appearance-none rounded-xl border bg-background pt-4 pr-20 pl-9 text-sm font-medium outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {NODES.map((n) => (
          <option key={n.id} value={n.id}>
            {n.name}
          </option>
        ))}
      </select>
    </div>
  )
}

function Switch({
  checked,
  onChange,
  label,
  tone = 'success',
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
  tone?: 'success' | 'destructive'
}) {
  return (
    <span className="relative inline-flex shrink-0">
      <input
        type="checkbox"
        role="switch"
        aria-label={label}
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="peer sr-only"
      />
      <span
        aria-hidden="true"
        className={cn(
          'flex h-6 w-11 items-center rounded-full p-0.5 transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-ring',
          checked ? (tone === 'success' ? 'bg-emerald' : 'bg-destructive') : 'bg-muted-foreground/30',
        )}
      >
        <span
          className={cn(
            'size-5 rounded-full bg-white shadow transition-transform',
            checked ? 'translate-x-5' : 'translate-x-0',
          )}
        />
      </span>
    </span>
  )
}
