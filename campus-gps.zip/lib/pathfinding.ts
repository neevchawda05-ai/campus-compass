import type { CampusEdge, CampusNode, EdgeKind } from './campus-data'

export interface PathfindingOptions {
  avoidStairs: boolean
  disabledNodeIds?: string[]
}

export interface RouteSegment {
  edge: CampusEdge
  from: CampusNode
  to: CampusNode
}

export type StepIcon = 'start' | 'left' | 'right' | 'straight' | 'elevator' | 'stairs' | 'ramp' | 'arrive'

export interface RouteStep {
  id: string
  text: string
  detail: string
  icon: StepIcon
  nodeId: string
  distance: number
}

export interface Route {
  nodeIds: string[]
  segments: RouteSegment[]
  distance: number
  minutes: number
  containsStairs: boolean
  steps: RouteStep[]
  accessibleMode: boolean
}

export function dijkstra(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  endId: string,
  { avoidStairs, disabledNodeIds = [] }: PathfindingOptions,
): { nodeIds: string[]; edges: CampusEdge[] } | null {
  const disabled = new Set(disabledNodeIds)
  const usableEdges = edges.filter(
    (e) => !(avoidStairs && e.requiresStairs) && !disabled.has(e.from) && !disabled.has(e.to),
  )

  const adjacency = new Map<string, { to: string; edge: CampusEdge }[]>()
  for (const node of nodes) adjacency.set(node.id, [])
  for (const e of usableEdges) {
    adjacency.get(e.from)?.push({ to: e.to, edge: e })
    adjacency.get(e.to)?.push({ to: e.from, edge: e })
  }

  const dist = new Map<string, number>()
  const prev = new Map<string, { node: string; edge: CampusEdge }>()
  const unvisited = new Set<string>()
  for (const node of nodes) {
    dist.set(node.id, Number.POSITIVE_INFINITY)
    unvisited.add(node.id)
  }
  dist.set(startId, 0)

  while (unvisited.size > 0) {
    let current: string | null = null
    let best = Number.POSITIVE_INFINITY
    for (const id of unvisited) {
      const d = dist.get(id) ?? Number.POSITIVE_INFINITY
      if (d < best) {
        best = d
        current = id
      }
    }
    if (current === null || current === endId) break
    unvisited.delete(current)

    for (const { to, edge } of adjacency.get(current) ?? []) {
      if (!unvisited.has(to)) continue
      const candidate = best + edge.distance
      if (candidate < (dist.get(to) ?? Number.POSITIVE_INFINITY)) {
        dist.set(to, candidate)
        prev.set(to, { node: current, edge })
      }
    }
  }

  if (!Number.isFinite(dist.get(endId) ?? Number.POSITIVE_INFINITY)) return null

  const nodeIds = [endId]
  const pathEdges: CampusEdge[] = []
  let cursor = endId
  while (cursor !== startId) {
    const step = prev.get(cursor)
    if (!step) return null
    pathEdges.unshift(step.edge)
    nodeIds.unshift(step.node)
    cursor = step.node
  }
  return { nodeIds, edges: pathEdges }
}

function compassHeading(dx: number, dy: number) {
  const angle = (Math.atan2(-dy, dx) * 180) / Math.PI
  const headings = ['east', 'northeast', 'north', 'northwest', 'west', 'southwest', 'south', 'southeast']
  const index = Math.round(((angle + 360) % 360) / 45) % 8
  return headings[index]
}

function turnDirection(prev: { x: number; y: number }, next: { x: number; y: number }): 'left' | 'right' | 'straight' {
  const cross = prev.x * next.y - prev.y * next.x
  const dot = prev.x * next.x + prev.y * next.y
  const angle = Math.abs((Math.atan2(cross, dot) * 180) / Math.PI)
  if (angle < 25) return 'straight'
  return cross > 0 ? 'right' : 'left'
}

function floorLabel(floor: number) {
  return floor === 0 ? 'Ground level' : `Floor ${floor}`
}

const KIND_SPEED: Record<EdgeKind, number> = { path: 1, ramp: 1.15, stairs: 1.4, elevator: 0.4 }

export function buildRoute(
  nodes: CampusNode[],
  edges: CampusEdge[],
  nodeMap: Record<string, CampusNode>,
  startId: string,
  endId: string,
  options: PathfindingOptions,
): Route | null {
  if (startId === endId) return null
  const result = dijkstra(nodes, edges, startId, endId, options)
  if (!result) return null

  const segments: RouteSegment[] = result.edges.map((edge, i) => ({
    edge,
    from: nodeMap[result.nodeIds[i]],
    to: nodeMap[result.nodeIds[i + 1]],
  }))

  const steps: RouteStep[] = []
  segments.forEach((segment, i) => {
    const { from, to, edge } = segment
    const vector = { x: to.x - from.x, y: to.y - from.y }
    let text: string
    let icon: StepIcon

    if (edge.kind === 'elevator') {
      icon = 'elevator'
      text = `Take ${edge.label ?? 'the elevator'} to ${floorLabel(to.floor)}`
    } else if (edge.kind === 'stairs') {
      icon = 'stairs'
      const verb = to.floor > from.floor ? 'Climb' : to.floor < from.floor ? 'Descend' : 'Take'
      text = `${verb} the ${edge.label ?? 'stairs'} to ${to.name}`
    } else if (edge.kind === 'ramp') {
      icon = 'ramp'
      text = `Follow the ${edge.label ?? 'ramp'} toward ${to.name}`
    } else if (i === 0) {
      icon = 'start'
      text = `Head ${compassHeading(vector.x, vector.y)} toward ${to.name}`
    } else {
      const prev = segments[i - 1]
      const turn = turnDirection({ x: prev.to.x - prev.from.x, y: prev.to.y - prev.from.y }, vector)
      icon = turn
      text =
        turn === 'straight'
          ? `Continue straight along the ${edge.label ?? 'path'} to ${to.name}`
          : `Turn ${turn} onto the ${edge.label ?? 'path'} toward ${to.name}`
    }

    steps.push({
      id: `${edge.id}-${i}`,
      text,
      detail: `${edge.distance} m · ${to.building} · ${floorLabel(to.floor)}`,
      icon,
      nodeId: to.id,
      distance: edge.distance,
    })
  })

  const destination = nodeMap[endId]
  steps.push({
    id: `arrive-${endId}`,
    text: `Arrive at ${destination.name}`,
    detail: `${destination.building} · ${floorLabel(destination.floor)}`,
    icon: 'arrive',
    nodeId: endId,
    distance: 0,
  })

  const distance = result.edges.reduce((sum, e) => sum + e.distance, 0)
  const metersPerMinute = options.avoidStairs ? 65 : 80
  const weighted = result.edges.reduce((sum, e) => sum + e.distance * KIND_SPEED[e.kind], 0)
  const elevatorWait = result.edges.filter((e) => e.kind === 'elevator').length * 0.75
  const minutes = Math.max(1, Math.round(weighted / metersPerMinute + elevatorWait))

  return {
    nodeIds: result.nodeIds,
    segments,
    distance,
    minutes,
    containsStairs: result.edges.some((e) => e.requiresStairs),
    steps,
    accessibleMode: options.avoidStairs,
  }
}
