export type Category = 'classroom' | 'lab' | 'restroom' | 'elevator' | 'food' | 'landmark'

export type EdgeKind = 'path' | 'ramp' | 'stairs' | 'elevator'

export interface CampusNode {
  id: string
  name: string
  building: string
  floor: number
  category: Category
  x: number
  y: number
  accessible: boolean
  labelBelow?: boolean
}

export interface CampusEdge {
  id: string
  from: string
  to: string
  distance: number
  kind: EdgeKind
  requiresStairs: boolean
  label?: string
}

export interface Building {
  id: string
  name: string
  x: number
  y: number
  width: number
  height: number
}

export const MAP_WIDTH = 1000
export const MAP_HEIGHT = 700

export const BUILDINGS: Building[] = [
  { id: 'eng', name: 'Engineering Hall', x: 110, y: 150, width: 240, height: 210 },
  { id: 'lib', name: 'Library Central', x: 420, y: 90, width: 180, height: 140 },
  { id: 'sci', name: 'Science Center', x: 690, y: 130, width: 220, height: 200 },
  { id: 'aud', name: 'Auditorium A', x: 110, y: 480, width: 230, height: 130 },
  { id: 'union', name: 'Student Union', x: 600, y: 500, width: 300, height: 130 },
]

export const NODES: CampusNode[] = [
  { id: 'gate', name: 'Main Gate', building: 'Campus Entrance', floor: 0, category: 'landmark', x: 500, y: 665, accessible: true },
  { id: 'plaza', name: 'Central Plaza', building: 'Outdoor', floor: 0, category: 'landmark', x: 500, y: 400, accessible: true },
  { id: 'eng-lobby', name: 'Engineering Lobby', building: 'Engineering Hall', floor: 1, category: 'landmark', x: 325, y: 330, accessible: true },
  { id: 'elev-west', name: 'Elevator West Wing', building: 'Engineering Hall', floor: 1, category: 'elevator', x: 150, y: 330, accessible: true, labelBelow: true },
  { id: 'room-204', name: 'Room 204', building: 'Engineering Hall', floor: 2, category: 'classroom', x: 170, y: 205, accessible: true },
  { id: 'lab-3', name: 'Computer Lab 3', building: 'Engineering Hall', floor: 2, category: 'lab', x: 290, y: 205, accessible: true },
  { id: 'library', name: 'Library Central', building: 'Library Central', floor: 1, category: 'landmark', x: 480, y: 150, accessible: true },
  { id: 'restroom-lib', name: 'Restroom — Library', building: 'Library Central', floor: 1, category: 'restroom', x: 565, y: 200, accessible: true },
  { id: 'sci-entrance', name: 'Science Center Entrance', building: 'Science Center', floor: 1, category: 'landmark', x: 735, y: 330, accessible: true },
  { id: 'sci-elev', name: 'Elevator East Wing', building: 'Science Center', floor: 1, category: 'elevator', x: 760, y: 190, accessible: true, labelBelow: true },
  { id: 'sci-lab', name: 'Chemistry Lab', building: 'Science Center', floor: 2, category: 'lab', x: 860, y: 190, accessible: true },
  { id: 'auditorium', name: 'Auditorium A', building: 'Auditorium A', floor: 0, category: 'classroom', x: 225, y: 480, accessible: true },
  { id: 'coffee', name: 'Brew Corner Café', building: 'Student Union', floor: 0, category: 'food', x: 650, y: 500, accessible: true },
  { id: 'cafeteria', name: 'Cafeteria', building: 'Student Union', floor: 0, category: 'food', x: 760, y: 565, accessible: true, labelBelow: true },
  { id: 'restroom-union', name: 'Restroom — Student Union', building: 'Student Union', floor: 0, category: 'restroom', x: 860, y: 565, accessible: true },
]

function edge(from: string, to: string, distance: number, kind: EdgeKind, label?: string): CampusEdge {
  return { id: `${from}__${to}`, from, to, distance, kind, requiresStairs: kind === 'stairs', label }
}

export const EDGES: CampusEdge[] = [
  edge('gate', 'plaza', 160, 'path', 'Main Avenue'),
  edge('gate', 'auditorium', 260, 'path', 'West Walk'),
  edge('gate', 'coffee', 190, 'path', 'Union Walk'),
  edge('plaza', 'eng-lobby', 180, 'stairs', 'Engineering front steps'),
  edge('plaza', 'auditorium', 240, 'path', 'Plaza West Path'),
  edge('auditorium', 'elev-west', 200, 'ramp', 'West Wing ramp'),
  edge('elev-west', 'eng-lobby', 175, 'path', 'ground floor corridor'),
  edge('eng-lobby', 'lab-3', 120, 'stairs', 'East stairwell'),
  edge('eng-lobby', 'room-204', 170, 'stairs', 'Central stairwell'),
  edge('elev-west', 'room-204', 115, 'elevator', 'Elevator West Wing'),
  edge('room-204', 'lab-3', 120, 'path', 'Floor 2 corridor'),
  edge('plaza', 'library', 250, 'stairs', 'Grand Library Staircase'),
  edge('library', 'restroom-lib', 80, 'path', 'reading room hallway'),
  edge('plaza', 'sci-entrance', 250, 'path', 'Science Walk'),
  edge('sci-entrance', 'restroom-lib', 230, 'ramp', 'Library east ramp'),
  edge('sci-entrance', 'sci-elev', 140, 'path', 'Science atrium'),
  edge('sci-elev', 'sci-lab', 90, 'elevator', 'Elevator East Wing'),
  edge('sci-entrance', 'sci-lab', 170, 'stairs', 'Science stairwell'),
  edge('plaza', 'coffee', 190, 'path', 'Plaza South Path'),
  edge('coffee', 'cafeteria', 110, 'path', 'Union concourse'),
  edge('cafeteria', 'restroom-union', 100, 'path', 'Union concourse'),
  edge('sci-entrance', 'cafeteria', 230, 'stairs', 'Hillside steps'),
]

export const NODE_MAP: Record<string, CampusNode> = Object.fromEntries(NODES.map((n) => [n.id, n]))

export const CATEGORY_FILTERS: { id: 'all' | Category; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'classroom', label: 'Classrooms' },
  { id: 'lab', label: 'Labs' },
  { id: 'restroom', label: 'Restrooms' },
  { id: 'elevator', label: 'Elevators' },
  { id: 'food', label: 'Food' },
]

export const TREES: [number, number, number][] = [
  [400, 300, 14], [420, 480, 12], [585, 300, 13], [600, 455, 11], [380, 560, 15],
  [60, 420, 16], [70, 120, 13], [380, 120, 12], [640, 60, 14], [950, 380, 15],
  [960, 120, 12], [560, 640, 11], [440, 640, 11], [60, 640, 14], [950, 650, 13],
  [380, 420, 10], [620, 360, 10], [660, 420, 12], [370, 360, 11], [940, 470, 11],
]
