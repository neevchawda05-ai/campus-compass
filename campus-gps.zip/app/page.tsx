import { CampusCompass } from '@/components/campus/campus-compass'

export default function Page() {
  return <CampusCompass />
}
